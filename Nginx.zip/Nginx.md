# Nginx: Instalación y configuración

## 1. Investigación

### Qué es Nginx

Nginx es un servidor web de código abierto creado por Igor Sysoev en 2004

### Diferencias con Apache

- Forma de trabajar: Apache usa un proceso o un hilo por cada conexión. Nginx funciona por eventos, con unos pocos procesos worker que atienden muchas conexiones a la vez.
- Contenido estático: Nginx es más rápido.
- Contenido dinámico: Apache puede ejecutar PHP con su propio módulo. Nginx no.
- Configuración: Apache permite archivos .htaccess en cada carpeta. Nginx no los tiene.
- Sitios: en Apache se usa VirtualHost y en Nginx bloques server.

### Instalación y ejecución en Ubuntu

Nginx está en los repositorios de Ubuntu, así que se instala con apt. Se maneja con systemctl igual que Apache. Los archivos importantes son:

- /etc/nginx/nginx.conf: configuración principal.
- /etc/nginx/sites-available y /etc/nginx/sites-enabled: los sitios, igual que en Apache.
- /var/www/html: la carpeta de la página por defecto.
- /var/log/nginx: los logs.

## 2. Implementación

Lo he hecho en la misma máquina virtual de Ubuntu de las prácticas de Apache. Como Apache ya usaba el puerto 80, Nginx no podía activarlo entonces he tenido que parar el apache:

```
sudo systemctl stop apache2
```

### Instalación de Nginx

```
sudo apt update
sudo apt install nginx
```

![Instalación de Nginx](img/01-apt-install.png)

Se comprueba que está funcionando:

```
sudo systemctl status nginx
```

![Estado de Nginx](img/02-status.png)

Sale active running y se ven el proceso master y los worker, que es como funciona Nginx.

### Crear la página

Se crea la carpeta del sitio y el index.html.

```
sudo mkdir -p /var/www/nginx-daniel
sudo nano /var/www/nginx-daniel/index.html
```

![Crear carpeta](img/03-mkdir.png)

![index.html](img/04-index.png)

### Configuración del bloque server

El bloque server es lo que en Apache sería el VirtualHost. Se crea un archivo para el sitio en sites-available.

```
sudo nano /etc/nginx/sites-available/nginx-daniel
```

![Crear archivo del sitio](img/05-nano-server.png)

![Bloque server](img/06-bloque-server.png)

- listen 80: el puerto en el que escucha.
- server_name: el dominio del sitio, nginx.example.com.
- root: la carpeta donde está la página.
- index: el archivo que carga por defecto.
- location con try_files: busca el archivo pedido y si no existe devuelve error 404.

Para activar el sitio se hace un enlace a sites-enabled:

```
sudo ln -s /etc/nginx/sites-available/nginx-daniel /etc/nginx/sites-enabled/
```

![Activar sitio](img/07-ln.png)

Como el dominio no existe se añade al archivo hosts:

```
echo "127.0.0.1 nginx.example.com" | sudo tee -a /etc/hosts
```

![Archivo hosts](img/08-hosts.png)

### Validación y aplicación de cambios

Con nginx -t se comprueba que la configuración no tiene errores y luego se recarga.

```
sudo nginx -t && sudo systemctl reload nginx
```

![nginx -t](img/09-nginx-t.png)

Sale syntax is ok y test is successful.

## 3. Comprobaciones

Al entrar en el navegador a http://nginx.example.com sale la página creada.

![Página en el navegador](img/10-navegador.png)

Con curl se ve la cabecera Server, que demuestra que la página la sirve Nginx y no Apache:

```
curl -I http://nginx.example.com
```

![curl](img/11-curl.png)

Devuelve 200 OK y Server: nginx/1.24.0.

## 4. Conclusiones

Se ha instalado Nginx en Ubuntu y se ha configurado un sitio propio con un bloque server, que funciona correctamente en nginx.example.com.

Dificultades encontradas:

- Apache estaba usando el puerto 80, así que tuve que pararlo para utilizar el nginx.
- Al instalar escribí ngin en vez de nginx y apt no encontraba el paquete.
- No se usó el dominio gci.example.com de las prácticas anteriores porque Firefox lo tenía guardado con HSTS y lo mandaba siempre a https, así que se creó uno nuevo.

Me ha parecido más sencillo de configurar que Apache.
