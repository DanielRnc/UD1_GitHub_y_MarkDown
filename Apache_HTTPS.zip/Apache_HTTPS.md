# Apache: HTTPS

## 1. Investigación

### Qué es HTTPS y por qué es importante

HTTPS es HTTP pero cifrado con TLS. Cuando el navegador se conecta al servidor primero se hace un handshake: el servidor manda su certificado, el navegador comprueba que es válido y entre los dos acuerdan una clave para cifrar todo lo que se mandan después. Por defecto va por el puerto 443 en vez del 80.

Es importante porque con HTTP normal todo va en texto plano y cualquiera que esté en la misma red puede leer lo que se envía, por ejemplo contraseñas o datos de formularios. Con HTTPS los datos van cifrados, no se pueden modificar por el camino y el navegador sabe que está hablando con el servidor correcto.

### Tipos de certificados

- Autofirmado: lo genera uno mismo con openssl y él mismo se firma.
- Firmado por una CA de confianza: lo emite una autoridad certificadora que el navegador ya conoce. El navegador lo acepta sin avisos y sale el candado normal. Es el que se usa en webs reales.

### Módulos de Apache necesarios

- ssl: es el que permite a Apache usar HTTPS. Al activarlo también activa socache_shmcb, que guarda en caché las sesiones SSL.
- headers: permite añadir cabeceras a las respuestas.

## 2. Implementación

Lo he hecho sobre el sitio gci.example.com de la práctica anterior, en la máquina virtual. He elegido la opción A, el certificado autofirmado, porque Let's Encrypt necesita un dominio real y que la máquina sea accesible desde internet.

### Comprobar Apache

Primero compruebo que Apache está instalado y funcionando.

```
sudo systemctl status apache2
```

![Estado de Apache](img/01-status.jpg)

Sale active running, así que está bien.

### Activar los módulos

```
sudo a2enmod ssl headers
sudo systemctl restart apache2
```

![Activar módulos ssl y headers](img/02-modulos.jpg)

Se ve que al activar ssl también activa socache_shmcb porque lo necesita.

### Generar el certificado

Se genera un certificado autofirmado válido para un año con una clave RSA de 2048 bits. La clave se guarda en /etc/ssl/private y el certificado en /etc/ssl/certs.

```
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/gci.key -out /etc/ssl/certs/gci.crt
```

![Generar certificado con openssl](img/03-openssl.jpg)

Después pide los datos del certificado. Lo importante es el Common Name, que tiene que ser el dominio, por eso he puesto todo lo demas igual.

![Datos del certificado](img/04-datos-certificado.jpg)

### Configurar el VirtualHost en el puerto 443

Se crea un archivo nuevo para el sitio con HTTPS.

```
sudo nano /etc/apache2/sites-available/gci-ssl.conf
```

![gci-ssl.conf](img/05-gci-ssl-conf.jpg)

Con SSLEngine on se activa SSL en este sitio y con SSLCertificateFile y SSLCertificateKeyFile se le dice dónde están el certificado y la clave. La línea Header añade la cabecera Strict-Transport-Security. También puse el bloque Directory con el usuario y contraseña de la práctica anterior, esta en cifrado.

Se activa el sitio:

```
sudo a2ensite gci-ssl.conf
```

### Redirección de HTTP a HTTPS

En el gci.conf del puerto 80 se añade debajo de DocumentRoot una línea para que todo lo que entre por HTTP se mande a HTTPS.

```
Redirect permanent / https://gci.example.com/
```

![Redirección en gci.conf](img/06-gci-conf-redirect.jpg)

### Comprobar y recargar

```
sudo apache2ctl configtest && sudo systemctl reload apache2
```

![configtest](img/07-configtest.jpg)

Sale Syntax OK. El aviso AH00558 sale porque no hay un ServerName global, pero no afecta.

## 3. Comprobaciones

### Navegador

Entrando en  gci.example.com el navegador va solo a https://gci.example.com y carga la página después de aceptar el aviso del certificado y poner el usuario.

![Página por HTTPS](img/08-navegador-https.jpg)

En la información de la página se ve que la conexión está cifrada con TLS 1.3.

![Información de seguridad](img/09-info-seguridad.jpg)

En el certificado se ve que el emisor y el asunto son el mismo, gci.example.com, porque es autofirmado. Es válido hasta noviembre de 2027.

![Certificado](img/10-certificado.jpg)

### curl

```
curl -I http://gci.example.com
curl -k -I https://gci.example.com
curl -k -I -u daniel https://gci.example.com
```

![Pruebas con curl](img/11-curl.jpg)

- Por HTTP devuelve 301 Moved Permanently con Location a https, así que la redirección funciona.
- Por HTTPS sin usuario devuelve 401 Unauthorized, y sale la cabecera Strict-Transport-Security.
- Por HTTPS con usuario y contraseña devuelve 200 que es que esta bien.

La opción -k se usa para que curl acepte el certificado autofirmado, si no da error.

## 4. Conclusiones

Conseguí que el sitio gci.example.com funcione por HTTPS con un certificado autofirmado, que lo que entre por HTTP se redirija a HTTPS y que se mantenga el control de acceso, ahora con la contraseña cifrada.

Dificultades encontradas:

- No he usado Let's Encrypt porque la máquina no tiene un dominio real.
- Firefox mostraba No seguro y no se veía si la URL era http o https porque oculta el principio. pero pinchando en la url se solucciona 
- Al crear el certificado puse en todos sitios ES seguramente eso haga que en el futuro halgo falle.
- Sigue saliendo el aviso AH00558 en el configtest, que no es un error.

La práctica me ha servido para ver que montar HTTPS en Apache es bastante rápido y que la diferencia entre un certificado autofirmado y uno de una CA no está en el cifrado sino en la confianza del navegador.